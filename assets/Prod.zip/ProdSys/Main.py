import re

all_conditions = dict()
all_actions = dict()
all_facts = []
all_prints = []

rules_file = 'rules'
facts_file = 'facts'

variable_literals = {
    'A': True,
    'B': True,
    'C': True,
    'D': True,
    'E': True,
    'F': True,
    'G': True,
    'H': True,
    'I': True,
    'J': True,
    'K': True,
    'L': True,
    'M': True,
    'N': True,
    'O': True,
    'P': True,
    'Q': True,
    'R': True,
    'S': True,
    'T': True,
    'U': True,
    'V': True,
    'W': True,
    'X': True,
    'Y': True,
    'Z': True,
}


def is_literal(literal):
    return True if variable_literals.get(literal) else False


def get_var(rule):
    return re.findall("\(([^\)]*)", rule)


def del_var(variable, rule):
    return re.sub('\(' + variable + '\)', '.', rule)


def load_facts(filename):
    file = open(filename, 'r')
    for line in file:
        single_fact = ()
        variables = get_var(line)
        for v in variables:
            line = del_var(v, line)
        single_fact += (line.strip(), *variables)
        all_facts.append(single_fact)


def load_rules(filename):
    file = open(filename, 'r')
    lines = [line.strip() for line in file]
    while lines:
        line1, line2, line3 = lines[:3]

        name = line1.strip()
        conditions = [condition.strip() for condition in line2.split(',')]
        actions = [action.strip() for action in line3.split(',')]

        comulator = []
        for c in conditions:
            m = get_var(c)
            for i in m:
                c = del_var(i, c)
            comulator.append((c.strip(), *m))
        all_conditions[name] = comulator

        comulator = []
        for a in actions:
            cmd = a.split(' ', 1)[0]
            a = a.split(' ', 1)[1]
            m = get_var(a)
            for i in m:
                a = del_var(i, a)
            comulator.append((cmd, a.strip(), *m))
        all_actions[name] = comulator

        lines = lines[3:]


def pretty_print(a):
    answer = a[1]
    for i in range(len(a[2:])):
        answer = answer.replace('.', a[2 + i], 1)
    print(answer)


def help_print(msg, a):
    print(msg, (a[1], *a[2:]))


def print_found(d, m, act, cond):
    if m + 1 >= len(all_conditions[cond]):
        for j in act:
            a = list(j)
            for k in range(len(a)):
                if d.get(a[k]):
                    a[k] = d[a[k]]
            if a[0] == 'pridaj':
                if (a[1], *a[2:]) not in all_facts:
                    all_facts.append((a[1], *a[2:]))
                    #help_print('added', a)
            elif a[0] == 'vymaz':
                if (a[1], *a[2:]) in all_facts:
                    all_facts.remove((a[1], *a[2:]))
                    #help_print('removed', a)
            elif a[0] == 'sprava':
                if (a[1], *a[2:]) not in all_prints:
                    pretty_print(a)
                    all_prints.append((a[1], *a[2:]))


# All combinations for a rule
def combinations(m, cond, d, act):
    #print('cond->', cond)
    if m >= len(all_conditions[cond]):
        return

    whole_condition = [*all_conditions[cond][m]]
    for i in range(len(whole_condition)):
        if d.get(whole_condition[i]):
            whole_condition[i] = d[whole_condition[i]]

    rule_context = all_conditions[cond][m][0]
    number_of_arguments = len(all_conditions[cond][m]) - 1

    args = []
    for i in range(number_of_arguments):
        args.append([])

    for i in all_facts:
        whole_copy = whole_condition.copy()
        if rule_context == '!= . .':
            if whole_copy[1] != whole_copy[2]:
                print_found(d, m, act, cond)
        elif i[0] == rule_context:
            for k in range(number_of_arguments):
                if is_literal(whole_copy[k+1]):
                    args[k].append(i[k + 1])
                    d[whole_copy[k+1]] = i[k+1]
                    whole_copy[k+1] = i[k+1]
                elif whole_copy[k+1] != i[k+1]:
                    break
                else:
                    args[k].append(i[k + 1])
            else:
                combinations(m + 1, cond, d.copy(), act[:])
                print_found(d, m, act, cond)


def main():
    load_facts(facts_file)
    load_rules(rules_file)

    old_len = 0
    new_len = len(all_facts)
    while old_len != new_len:
        for key, value in all_conditions.items():
            combinations(0, key, dict(), all_actions[key][:])
        old_len = new_len
        new_len = len(all_facts)

    #print(len(all_facts))
    #
    # for f in all_facts:
    #     print(f)
    #
    # for c in all_conditions.items():
    #     print(c)
    #
    # for a in all_actions.items():
    #     print(a)



if __name__ == '__main__':
    main()
