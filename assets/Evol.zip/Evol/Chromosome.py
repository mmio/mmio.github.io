class Chromosome:
    def __init__(self, program=None, fitness=None):
        self.program = program
        self.fit = fitness
        self.ranks = 0
